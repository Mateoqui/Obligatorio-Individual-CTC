

const CONTRASEÑAS = [
    {servicio: "Juan Lacaze", nombre: "Mateo Quiroga", contraseña: "quiroga", nivelDeSeguridad: "bajo"}
];
let editIndex = null;

function actualizarContraseña() {
    const servicio = document.getElementById('servicio').value;
    const nombre = document.getElementById('nombre').value;
    const contraseña = document.getElementById('contraseña').value;
    const nivelDeSeguridad = document.getElementById('nivelDeSeguridad').value;

    CONTRASEÑAS[editIndex] = { servicio, nombre, contraseña, nivelDeSeguridad };
    mostrarContraseñas();
    limpiarFormulario();
    document.getElementById('updateBtn').style.display = 'none';
}

function crearContraseña() {
    const servicio = document.getElementById('servicio').value;
    let nombre = document.getElementById('nombre').value;
    let contraseña = document.getElementById('contraseña').value;
    const nivelDeSeguridad = document.getElementById('nivelDeSeguridad').value;

    let encriptado;
    if (nivelDeSeguridad === "bajo"){
        encriptado = "nivel1";
        let auxContraseña = contraseña;
        let auxNombre = nombre;
        contraseña = encrypt(auxContraseña, encriptado);
        nombre = encrypt(auxNombre, encriptado);
    }
    else if (nivelDeSeguridad === "medio"){
        encriptado = "nivel2";
        let auxContraseña = contraseña;
        let auxNombre = nombre;
        contraseña = encrypt(auxContraseña, encriptado);
        nombre = encrypt(auxNombre, encriptado);
    }
    else if (nivelDeSeguridad === "alto"){
        encriptado = "nivel3";
        let auxContraseña = contraseña;
        let auxNombre = nombre;
        contraseña = encrypt(auxContraseña, encriptado);
        nombre = encrypt(auxNombre, encriptado);
    }

    const nuevaContraseña = { servicio, nombre, contraseña, nivelDeSeguridad };



    CONTRASEÑAS.push(nuevaContraseña);
    mostrarContraseñas();
    limpiarFormulario();
}

function mostrarContraseñas() {
    const lista = document.getElementById('listaContraseñas');
    lista.innerHTML = '';
    CONTRASEÑAS.forEach((c, index) => {
        const item = document.createElement('li');
        item.className = 'list-group-item';
        item.innerHTML = `
            ${c.servicio} - ${c.nombre} - ${c.contraseña} -${c.nivelDeSeguridad}
            <button class="btn btn-sm btn-warning" onclick="editarContraseña(${index})">Editar</button>
            <button class="btn btn-sm btn-danger" onclick="eliminarContraseña(${index})">Eliminar</button>
            <button class="btn btn-sm btn-secondary" onclick="desencriptarDatos(${index})">Mostrar</button>
        `;
        lista.appendChild(item);
    });
}

function cargarVideojuegos(videojuegos) {
    const container = document.getElementById('videojuegosContainer');
    container.innerHTML = '';
    videojuegos.forEach(vj => {
        const card = document.createElement('div');
        card.className = 'col-md-4';
        card.innerHTML = `
            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title">${vj.nombre}</h5>
                    <p class="card-text">${vj.descripcion}</p>
                    <p class="card-text">$${vj.precio}</p>
                    <button class="btn btn-primary" onclick="agregarAlCarrito(${vj.id})">Agregar al Carrito</button>
                </div>
            </div>
        `;
        container.appendChild(card);
    });
}




function filtrarContraseñas(contraseña){
    const filtro = document.getElementById("listaContraseñas")
    filtro.innerHTML = '';
    contraseña.forEach((c, index) =>{
        const item = document.createElement('li');
        item.className = 'list-group-item';
        item.innerHTML = `
            ${c.servicio} - ${c.nombre} - ${c.contraseña} -${c.nivelDeSeguridad}
            <button class="btn btn-sm btn-warning" onclick="editarContraseña(${index})">Editar</button>
            <button class="btn btn-sm btn-danger" onclick="eliminarContraseña(${index})">Eliminar</button>
            <button class="btn btn-sm btn-secondary" onclick="desencriptarDatos(${index})">Mostrar</button>
        `;
        filtro.appendChild(item);
    })
}

function limpiarFormulario() {
    document.getElementById('servicio').value = '';
    document.getElementById('nombre').value = '';
    document.getElementById('contraseña').value = '';
    document.getElementById('nivelDeSeguridad').value = 'Seleccione dificultad';
    editIndex = null;
}

function editarContraseña(index) {
    const contraseña = CONTRASEÑAS[index];
    document.getElementById('servicio').value = contraseña.servicio;
    document.getElementById('nombre').value = contraseña.nombre;
    document.getElementById('contraseña').value = contraseña.contraseña;
    document.getElementById('nivelDeSeguridad').value = contraseña.nivelDeSeguridad;
    editIndex = index;
    document.getElementById('updateBtn').style.display = 'inline';
}

function eliminarContraseña(index) {

    let respuesta = confirm("¿Estas seguro que quieres eliminar esta contraseña?")
    if(respuesta === true){
        CONTRASEÑAS.splice(index, 1);
        mostrarContraseñas();
    }
    else if (respuesta === false){
        mostrarContraseñas();
    }
}

function desencriptarDatos(index){
    const contraseña = CONTRASEÑAS[index];
    let seguridad = detectarSeguridad(contraseña.nivelDeSeguridad)
    let desencriptarContraseña = decrypt(contraseña.contraseña, seguridad)
    let desencriptarNombre = decrypt(contraseña.nombre, seguridad)
    alert("Nombre: " + desencriptarNombre + " | Contraseña: " + desencriptarContraseña);
}

function detectarSeguridad(nivel){
    let encriptado;
    if (nivel === "bajo"){
        encriptado = "nivel1"
    }
    else if (nivel === "medio"){
        encriptado = "nivel2"
    }
    else if (nivel === "alto"){
        encriptado = "nivel3"
    }

    return encriptado;
}

function filtrarPorNivel() {
    const nivelDeSeguridad = document.getElementById('filtroNivelDeSeguridad').value; // Cambia el ID si es necesario
    const filtrados = nivelDeSeguridad === 'todos' ? CONTRASEÑAS : CONTRASEÑAS.filter(c => c.nivelDeSeguridad === nivelDeSeguridad);
    filtrarContraseñas(filtrados);
}

// Funciones de cifrado y descifrado
function encrypt(data, key) {
  return btoa(data.split('').map((c, i) => c.charCodeAt(0) ^ key[i % key.length].charCodeAt(0)).map(c => String.fromCharCode(c)).join(''));
}

function decrypt(data, key) {
    const decodedData = atob(data);
    return decodedData.split('').map((c, i) => c.charCodeAt(0) ^ key[i % key.length].charCodeAt(0)).map(c => String.fromCharCode(c)).join('');
  }